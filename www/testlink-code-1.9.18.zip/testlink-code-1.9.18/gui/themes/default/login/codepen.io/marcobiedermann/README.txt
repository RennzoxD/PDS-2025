A Pen created at CodePen.io. You can find this one at http://codepen.io/marcobiedermann/pen/Fybpf.

 Inspired by <a href="http://dribbble.com/shots/975425-Flat-UI-login">Virgil Pana</a>