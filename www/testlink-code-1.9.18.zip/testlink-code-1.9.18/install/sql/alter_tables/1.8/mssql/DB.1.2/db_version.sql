/* 
tcversions.sql - postgres
$File:$
$Revision: 1.1 $
$Date: 2008/01/02 18:55:52 $
$Author: franciscom $
$Name:  $
*/
ALTER TABLE db_version ADD notes TEXT NULL;